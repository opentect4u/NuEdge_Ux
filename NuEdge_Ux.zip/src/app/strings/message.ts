export const ADD_MESSAGE = `Success!! Saved Successfully`;
export const ERROR_MESSAGE = `Error!! Something Went Wrong`;
export const UPDATE_MESSAGE = `Success!! Updated Successfully`;
export const AUTHORIZATION_MESSAGE = `UNAUTHORIZE!! You Are Not Permitted To Access`;
export const SERVER_ERROR = `Error!! Internal Server Error`;
export const MAP_PLAN_OPT = `SUCCESS!! Plan Option Mapped Successfully`;
export const MAP_BU_TYPE = `SUCCESS!! Business Type Mapped Successfully`;
export const FAMILY_CREATE = `SUCCESS!! Family Created Successfully`;
export const FAMILY_UPDATE = `SUCCESS!! Family Created Successfully`;

