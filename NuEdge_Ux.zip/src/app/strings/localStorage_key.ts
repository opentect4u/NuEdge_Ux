export const AU_TK = '4BTgxOleKn';
export const US_IN = 'V1uSoeGR';
export const EN_DE = '0a045a8a6fa68f912251ab856444ff1e76a5867a5eecd892ed1579ab5c5bc415O4p1346FdvPbbNX7jXN4Rg==';
export const ERRR = 'U2FsdGVkX18CXBrvvdQDAbytrZBR5gQDSJdZh8+TbjE=';
export const SCM_DTLS = 'YSD05CVM'

