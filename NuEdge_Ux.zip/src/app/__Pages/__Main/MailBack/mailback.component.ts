import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailback',
  templateUrl: './mailback.component.html',
  styleUrls: ['./mailback.component.css']
})
export class MailbackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
