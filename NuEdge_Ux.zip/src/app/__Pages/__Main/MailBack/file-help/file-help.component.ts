import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-help',
  templateUrl: './file-help.component.html',
  styleUrls: ['./file-help.component.css']
})
export class FileHelpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
