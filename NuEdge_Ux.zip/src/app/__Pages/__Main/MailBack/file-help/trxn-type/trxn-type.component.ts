import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trxn-type',
  templateUrl: './trxn-type.component.html',
  styleUrls: ['./trxn-type.component.css']
})
export class TrxnTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
