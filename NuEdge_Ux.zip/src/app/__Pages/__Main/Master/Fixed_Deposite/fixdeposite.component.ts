import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fixdeposite',
  templateUrl: './fixdeposite.component.html',
  styleUrls: ['./fixdeposite.component.css']
})
export class FixdepositeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
