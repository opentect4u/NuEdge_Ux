import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ins-lnd',
  templateUrl: './ins-lnd.component.html',
  styleUrls: ['./ins-lnd.component.css']
})
export class InsLndComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
