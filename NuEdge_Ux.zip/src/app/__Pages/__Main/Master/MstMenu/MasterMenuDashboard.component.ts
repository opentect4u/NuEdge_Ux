import { Component, OnInit } from '@angular/core';

@Component({
selector: 'MstMenu-component',
templateUrl: './MasterMenuDashboard.component.html',
styleUrls: ['./MasterMenuDashboard.component.css']
})
export class MastermenudashboardComponent implements OnInit {

constructor() {
}

ngOnInit(){

}
}
