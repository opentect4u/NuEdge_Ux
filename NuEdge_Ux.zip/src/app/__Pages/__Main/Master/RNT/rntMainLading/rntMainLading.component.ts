import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rntMainLading',
  templateUrl: './rntMainLading.component.html',
  styleUrls: ['./rntMainLading.component.css']
})
export class RntMainLadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
