import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catMainLanding',
  templateUrl: './catMainLanding.component.html',
  styleUrls: ['./catMainLanding.component.css']
})
export class CatMainLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
