import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merge-amc',
  templateUrl: './merge-amc.component.html',
  styleUrls: ['./merge-amc.component.css']
})
export class MergeAmcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
