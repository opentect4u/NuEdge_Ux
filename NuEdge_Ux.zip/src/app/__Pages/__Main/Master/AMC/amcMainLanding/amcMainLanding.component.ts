import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amcMainLanding',
  templateUrl: './amcMainLanding.component.html',
  styleUrls: ['./amcMainLanding.component.css']
})
export class AmcMainLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
