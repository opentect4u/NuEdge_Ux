import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-optMainLanding',
  templateUrl: './optMainLanding.component.html',
  styleUrls: ['./optMainLanding.component.css']
})
export class OptMainLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
