import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planMainLanding',
  templateUrl: './planMainLanding.component.html',
  styleUrls: ['./planMainLanding.component.css']
})
export class PlanMainLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
