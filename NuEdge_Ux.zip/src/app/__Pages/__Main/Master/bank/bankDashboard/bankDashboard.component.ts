import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bankDashboard',
  templateUrl: './bankDashboard.component.html',
  styleUrls: ['./bankDashboard.component.css']
})
export class BankDashboardComponent implements OnInit {


constructor() { }

ngOnInit() {
}


}
