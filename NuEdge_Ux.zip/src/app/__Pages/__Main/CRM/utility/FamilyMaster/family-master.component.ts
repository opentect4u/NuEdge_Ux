import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-family-master',
  templateUrl: './family-master.component.html',
  styleUrls: ['./family-master.component.css']
})
export class FamilyMasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
