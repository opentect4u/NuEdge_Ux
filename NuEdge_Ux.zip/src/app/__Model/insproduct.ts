export class insProduct{
  public id: number;
  public company_id:number;
  public ins_type_id: number;
  public product_name:string
  public ins_type_name:string;
  public comp_short_name:string;
  public comp_full_name:string;
  public product_type_id: number;
  public product_type: string;
}
