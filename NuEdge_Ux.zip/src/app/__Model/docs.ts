export class docs{
    id: number;
    client_id:number;
    doc_type_id:number;
    doc_name:string;
}