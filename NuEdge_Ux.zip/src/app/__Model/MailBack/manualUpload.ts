export interface manualUpload{
    rnt_id:number;
    rnt_name:string | null;
    file_type_id:number;
    file_type_name:string | null;
    file_id:number;
    file_name:string | null;
    upload_file:string | null;
    id:number;
    process_date:Date;
}
