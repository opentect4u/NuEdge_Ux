export class MatMenuListItem {
  title:string;
  icon: string;
  isDisabled: boolean;
  flag:string;
}
