export class totalAmt{
  net_amt:number | undefined = 0;
  tds:number | undefined = 0;
  stamp_duity:number | undefined = 0;
  gross_amt:number | undefined = 0;

}
