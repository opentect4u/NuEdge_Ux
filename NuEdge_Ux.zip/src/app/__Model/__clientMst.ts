import { docs } from "./docs"

export interface client {
    client_name: string
    client_code: string
    dob?: number
    pan?: string
    mobile?: number
    sec_mobile?: number
    email?: string
    sec_email?: string
    add_line_1?: string
    add_line_2?: string
    city?: string
    dist?: string
    state?: string
    pincode?: number
    id: number
    created_by?:number
    created_at?:string
    updated_by?:number
    updated_at?:string
    gurdians_name?: string
    gurdians_pan?: string
    relation?: string;
    client_doc?:docs[]
    client_type?: string,
    anniversary_date?: string,
    dob_actual?: string;
    client_type_mode?: string;
  }
