export interface docType {
    created_at: string
    created_by: number
    doc_type: string
    id: number
    updated_at: string
    updated_by: any
  }
  