export interface bank {
    bank_name: string
    created_at?: string
    created_by?: number
    deleted_at?: any
    deleted_by?: any
    deleted_flag?: string
    id: number
    ifs_code: string
    updated_at?: string
    updated_by?: any
    branch_name:string,
    micr_code:string,
    branch_addr:string
  }
