export interface trnsType {
    created_at: string
    created_by: number
    id: number
    trans_id: number
    trns_name: string
    updated_at: string
    updated_by: any
  }
  