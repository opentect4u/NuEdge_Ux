export interface swpType{
  created_at?:string;
  id: number;
  swp_type_name: string
  updated_at?: string
}
