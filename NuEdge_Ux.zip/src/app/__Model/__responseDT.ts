
/****************GET RESPONSE FROM BACKEND IN THE FOLLOWING FORMAT***********************/
export interface responseDT {
    suc: number;
    data: any;
    message: string;
    msg?:string;
}
/****************END***********************/
