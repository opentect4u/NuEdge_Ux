export interface view{
     id:number;
     icon:string;
     title:string;
     scores:number;
}