export interface column{
    field: string;
    header: string;
    width?:string;
    "max-width"?:string;
  "min-width"?: string;
    isVisible?:any;
    isFrozen?:boolean;
}
