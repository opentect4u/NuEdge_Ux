export interface submenu{
    id: number,
    title?:string | null,
    menu_name?:string | null,
    has_submenu?:string
    url:string,
    img?:string | null,
    icon?:string | null
}
