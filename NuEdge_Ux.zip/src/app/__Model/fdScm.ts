export interface fdScm {
  id: number;
  comp_type_id: string;
  comp_type: string;
  comp_id: string;
  comp_short_name: string;
  comp_full_name: string;
  scheme_name: string;

}
