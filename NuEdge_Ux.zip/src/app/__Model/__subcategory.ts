export interface subcat {
    category_id: number;
    created_at: string;
    created_by: number;
    id: number;
    cat_name: string;
    subcategory_name: string;
    updated_at: string;
    updated_by: any;
  }
