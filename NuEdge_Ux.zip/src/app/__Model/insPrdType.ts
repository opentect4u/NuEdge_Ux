export class insPrdType{
  id: number;
  public ins_type_id: number;
  public product_type: string;
  ins_type: string;
}
