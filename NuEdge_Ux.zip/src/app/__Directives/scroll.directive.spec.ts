import { ScrollDirective } from './scroll.directive';

describe('ScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollDirective();
    expect(directive).toBeTruthy();
  });
});
