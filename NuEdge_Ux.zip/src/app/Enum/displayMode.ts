export enum  displayMode{
    collapsed,
    expanded
}

export enum SystamaticfileHelp{
    T  = "rntSystematicTransType",
    F  = "rntSystematicFrequency",
    U  = "rntSystematicUnregister",
    TS = "rntFolioDetails"
}
