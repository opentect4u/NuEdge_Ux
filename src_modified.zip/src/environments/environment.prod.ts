export const environment = {
  production: true,
  apiUrl: "https://opentech4u.co.in/nuedge_api/api/v1",
  clientdocUrl: "https://opentech4u.co.in/nuedge_api/public/client-doc/",
  app_formUrl:"https://opentech4u.co.in/nuedge_api/public/application-form/",
  ack_formUrl:"https://opentech4u.co.in/nuedge_api/public/acknowledgement-copy/"
};
