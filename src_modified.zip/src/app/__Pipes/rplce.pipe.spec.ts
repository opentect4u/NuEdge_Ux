/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { RplcePipe } from './rplce.pipe';

describe('Pipe: Rplcee', () => {
  it('create an instance', () => {
    let pipe = new RplcePipe();
    expect(pipe).toBeTruthy();
  });
});
