/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ReplacePipe } from './replace.pipe';

describe('Pipe: Replacee', () => {
  it('create an instance', () => {
    let pipe = new ReplacePipe();
    expect(pipe).toBeTruthy();
  });
});
