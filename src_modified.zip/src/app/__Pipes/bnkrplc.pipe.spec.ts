/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { BnkrplcPipe } from './bnkrplc.pipe';

describe('Pipe: Bnkrplce', () => {
  it('create an instance', () => {
    let pipe = new BnkrplcPipe();
    expect(pipe).toBeTruthy();
  });
});
