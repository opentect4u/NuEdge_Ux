export interface plan {

    id: number;
    plan_name: string;
    created_by: number;
    created_at: string;
    updated_by: number;
    updated_at: string;
}