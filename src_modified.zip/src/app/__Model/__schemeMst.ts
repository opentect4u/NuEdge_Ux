export interface scheme {
    created_at: string
    created_by: number
    id: number
    updated_at: string
    updated_by: any
    category_id: number
    subcategory_id: number
    product_id: number
    amc_id: number
    scheme_name:string
    scheme_type:string
    nfo_start_dt:string
  nfo_end_dt:string
  nfo_reopen_dt:string
  pip_fresh_min_amt:string
  sip_fresh_min_amt:string
  pip_add_min_amt:string
  sip_add_min_amt:string
  isin_no:string,
  }
  