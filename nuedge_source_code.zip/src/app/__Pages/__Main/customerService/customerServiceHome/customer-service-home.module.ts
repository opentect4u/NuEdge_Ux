import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerServiceHomeComponent } from './customer-service-home.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { TabModule } from 'src/app/__Core/tab/tab.module';
import { ModifyQueryStatusComponent } from '../modify-query-status/modify-query-status.component';
import { DocViewComponent } from './dialog/doc-view.component';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { DialogModule } from 'primeng/dialog';
import { TatRemarksComponent } from './tat-remarks/tat-remarks.component';
const routes:Routes = [
  {
    path:'',
    component:CustomerServiceHomeComponent
  }
]

@NgModule({
  declarations: [
    CustomerServiceHomeComponent,
    ModifyQueryStatusComponent,
    DocViewComponent,
    TatRemarksComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    TabModule,
    DialogModule,
    OverlayPanelModule
  ]
})
export class CustomerServiceHomeModule { }
