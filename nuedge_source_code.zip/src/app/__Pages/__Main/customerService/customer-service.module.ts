import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerServiceComponent } from './customer-service.component';
import { RouterModule, Routes } from '@angular/router';
// import { TatRemarksComponent } from './tat-remarks/tat-remarks.component';

const routes:Routes = [
  {
    path:'',
    component:CustomerServiceComponent,
    data: { breadcrumb: 'Customer Service',Title:'Customer Service',pageTitle:'Customer Service' },
    children:[
      {
        path:'',
        loadChildren:() => import('./customerServiceHome/customer-service-home.module').then(m => m.CustomerServiceHomeModule),
      },
      {
        path:':queryId/:productId',
        loadChildren:() => import('./query-entry-screen/query-entry-screen.module').then(m => m.QueryEntryScreenModule)
      },
      {
        path:'viewTrans/:queryId/:productId',
        loadChildren:() => import('./view-entry/view-entry.module').then(m => m.ViewEntryModule)
      }
      // {
      //   path:'',
      //   pathMatch:'full',
      //   redirectTo:'customer-service-options'
      // }, customer-service-options
    ]
  }
]

@NgModule({
  declarations: [
    CustomerServiceComponent,
    // TatRemarksComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CustomerServiceModule { }
