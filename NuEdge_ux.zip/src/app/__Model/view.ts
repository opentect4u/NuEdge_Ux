export class view{
    public id:number;
    public icon:string;
    public title:string;
    public scores:number;
}