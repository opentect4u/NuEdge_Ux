export class menuList{
    public id:number;
    public icon:string;
    public title:string;
    public img:string;
    public flag:string;
    public url:string;

}