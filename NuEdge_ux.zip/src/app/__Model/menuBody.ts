export class menuBodyList{
    public id:number;
    public icon:string;
    public title:string;
    public img:string;
    public value:number;
    public url:string;
    public class:string;

}