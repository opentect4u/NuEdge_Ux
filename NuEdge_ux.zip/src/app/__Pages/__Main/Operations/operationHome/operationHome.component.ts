import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'operations-operationHome',
  templateUrl: './operationHome.component.html',
  styleUrls: ['./operationHome.component.css']
})
export class OperationHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
