import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mstOpDashboard',
  templateUrl: './mstOpDashboard.component.html',
  styleUrls: ['./mstOpDashboard.component.css']
})
export class MstOpDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
