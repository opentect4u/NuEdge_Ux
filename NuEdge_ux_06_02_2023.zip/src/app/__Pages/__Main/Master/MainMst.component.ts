import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-MainMst',
  templateUrl: './MainMst.component.html',
  styleUrls: ['./MainMst.component.css']
})
export class MainMstComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
