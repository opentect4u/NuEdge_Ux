import { Component, OnInit } from '@angular/core';
import { UtiliService } from 'src/app/__Services/utils.service';

@Component({
  selector: 'app-mfTrax',
  templateUrl: './mfTrax.component.html',
  styleUrls: ['./mfTrax.component.css']
})
export class MfTraxComponent implements OnInit {

  constructor() {
   }

  ngOnInit() {
  }

}
