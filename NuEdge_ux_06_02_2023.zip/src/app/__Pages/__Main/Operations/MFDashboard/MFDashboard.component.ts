import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-MFDashboard',
  templateUrl: './MFDashboard.component.html',
  styleUrls: ['./MFDashboard.component.css']
})
export class MFDashboardComponent implements OnInit {

  __menus = [
    
  ]

  constructor() { }

  ngOnInit() {
  }

}
