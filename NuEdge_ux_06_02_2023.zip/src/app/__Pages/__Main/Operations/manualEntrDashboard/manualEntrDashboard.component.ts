import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manualEntrDashboard',
  templateUrl: './manualEntrDashboard.component.html',
  styleUrls: ['./manualEntrDashboard.component.css']
})
export class ManualEntrDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
