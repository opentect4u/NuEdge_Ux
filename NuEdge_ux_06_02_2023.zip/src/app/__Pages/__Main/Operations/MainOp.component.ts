import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-MainOp',
  templateUrl: './MainOp.component.html',
  styleUrls: ['./MainOp.component.css']
})
export class MainOpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
