export interface rcvForm {
    application_no: string
    arn_no: string
    branch_code: string
    bu_type: string
    created_at: string
    created_by: number
    email: string
    euin_from: string
    euin_to: string
    trans_id: number
    mobile: number
    pan_no: string
    product_id: number
    rec_datetime: string
    sub_arn_no: any
    sub_brk_cd: any
    temp_tin_id: string
    updated_at: string
    updated_by: any
    trans_name:string
}