export interface menuList {
    id: number;
    icon: string;
    title: string;
    img: string;
    flag: string;
    url: string;

}