export interface submenu{
    id: number,
    menu_name:string
    has_submenu:string
    url:string
}