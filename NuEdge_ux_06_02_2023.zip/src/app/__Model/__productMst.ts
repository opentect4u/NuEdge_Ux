export interface product {
    created_at: string
    created_by: number
    id: number
    product_name: string
    updated_at: string
    updated_by: any
}
