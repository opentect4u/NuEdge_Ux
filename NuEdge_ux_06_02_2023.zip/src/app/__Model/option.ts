export interface option{
    id: number;
    opt_name: string;
    created_by: number;
    created_at: string;
    updated_by: number;
    updated_at: string;
}