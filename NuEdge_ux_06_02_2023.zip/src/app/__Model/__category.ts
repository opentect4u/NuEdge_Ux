export interface category {
    cat_name: string
    created_at: string
    created_by: number
    id: number
    product_id: number
    updated_at: string
    updated_by: any
}
