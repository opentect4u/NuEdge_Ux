
/****************GET RESPONSE OF RNT MASTER FROM BACKEND IN THE FOLLOWING FORMAT***********************/
export interface rnt {
     id: number;
     rnt_name: string;
     created_at: string;
     created_by: number;
     updated_at: string;
     updated_by: number;
     ofc_addr?: any;
     website: any;
     cus_care_no?:number
     cus_care_email?:any

}
/****************END***********************/
